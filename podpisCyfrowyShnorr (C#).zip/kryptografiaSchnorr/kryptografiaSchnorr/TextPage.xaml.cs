﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kryptografiaSchnorr {
    /// <summary>
    /// Interaction logic for TextPage.xaml
    /// </summary>
    public partial class TextPage : Page {

        private CryptoSchnorr objSchnorr = new CryptoSchnorr();
        private Tuple<string, string> TextPodpis { get; set; }
        private string TextPodpisSciezka;

        public TextPage() {
            InitializeComponent();
        }

        private void Wprowadz_tekst(object sender, RoutedEventArgs e) {
            TextPage textPage = new TextPage();
            this.NavigationService.Navigate(textPage);
            radio_text.IsChecked = true;
        }
        private void Wybierz_Plik(object sender, RoutedEventArgs e) {
            PlikPage plikPage = new PlikPage();
            this.NavigationService.Navigate(plikPage);
            radio_plik.IsChecked = true;
        }

        private void Deszyfrowanie_pliku_button(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == true)
            {
                TextPodpis = new Tuple<string, string>(File.ReadLines(dialog.FileName).First(), File.ReadLines(dialog.FileName).Skip(1).First());
            }
            TextPodpisSciezka = dialog.FileName;
        }

        private void Szyfrowanie_pliku_button(object sender, RoutedEventArgs e) {
            var podpis = objSchnorr.generowaniePodpisu(Encoding.GetEncoding("ISO-8859-2").GetBytes(pole_szyfruj.Text));
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Signature (*.signature)|*.signature";
            if (saveFileDialog.ShowDialog() == true) {
                File.WriteAllText(saveFileDialog.FileName, podpis.Item1 + Environment.NewLine + podpis.Item2);
            }
        }

        private void Wyczyszczenie_jawny_button(object sender, RoutedEventArgs e) {
            pole_szyfruj.Text = "";
        }

        private void Wyczyszczenie_krypto_button(object sender, RoutedEventArgs e) {
            try {
                wiadomosc(objSchnorr.weryfikacjaPodpisu(Encoding.GetEncoding("ISO-8859-2").GetBytes(pole_szyfruj.Text), TextPodpis.Item1, TextPodpis.Item2));
            } catch (Exception exc) {
                System.Windows.MessageBox.Show("Nalezy wprowadzic plik z podpisem");
            }

        }

        private void wiadomosc(bool wart) {
            System.Windows.MessageBox.Show(wart ? "Podpis poprawny :)" : "Podpis niestety niepoprawny :/");

        }

        private void pole_szyfruj_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
