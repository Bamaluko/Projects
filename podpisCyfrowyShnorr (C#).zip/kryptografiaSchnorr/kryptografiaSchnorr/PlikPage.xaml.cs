﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace kryptografiaSchnorr {
    /// <summary>
    /// Interaction logic for PlikPage.xaml
    /// </summary>
    public partial class PlikPage : Page {

        private CryptoSchnorr objSchnorr = new CryptoSchnorr();
        private Tuple<string, string> Plik_podpis { get; set; }
        public string Sciezka_do_pliku_podpis;
        private byte[] Plik_binarny_pusty { get; set; }
        public string Sciezka_do_pustego_pliku;
        private byte[] Plik_binarny_podpisany { get; set; }
        public string Sciezka_do_podpisanego_pliku;

        public PlikPage() {
            InitializeComponent();
        }

        private void Wprowadzenie_tekstu(object sender, RoutedEventArgs e) {
            TextPage textPage = new TextPage();
            this.NavigationService.Navigate(textPage);
        }

        private void Wybranie_pliku(object sender, RoutedEventArgs e) {
            PlikPage plikPage = new PlikPage();
            this.NavigationService.Navigate(plikPage);
        }

        private void Zaladowanie_wczytywanie_podpisu(object sender, RoutedEventArgs e) {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == true) {
                Plik_podpis = new Tuple<string, string>(File.ReadLines(dialog.FileName).First(), File.ReadLines(dialog.FileName).Skip(1).First());
            }
            Sciezka_do_pliku_podpis = dialog.FileName;

        }

        private void Wczytanie_pliku_do_szyfrowania(object sender, RoutedEventArgs e) {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == true)
                Plik_binarny_pusty = File.ReadAllBytes(dialog.FileName);
            Sciezka_do_pustego_pliku = dialog.FileName;
        }

        private void Szyfrowanie_pliku(object sender, RoutedEventArgs e) {
            var podpis = objSchnorr.generowaniePodpisu(Plik_binarny_pusty);
            File.WriteAllText(Sciezka_do_pustego_pliku + ".signature", podpis.Item1 + Environment.NewLine + podpis.Item2);
        }

        private void Wczytanie_pliku_do_deszyfrowania(object sender, RoutedEventArgs e) {
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == true) {
                Plik_binarny_podpisany = File.ReadAllBytes(dialog.FileName);
            }
            Sciezka_do_podpisanego_pliku = dialog.FileName;
        }

        private void wiadomosc(bool wart) {
            System.Windows.MessageBox.Show(wart ? "Podpis poprawny :)" : "Podpis niestety niepoprawny :/");

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                wiadomosc(objSchnorr.weryfikacjaPodpisu(Plik_binarny_podpisany, Plik_podpis.Item1, Plik_podpis.Item2));
            }
            catch (Exception exc)
            {
                System.Windows.MessageBox.Show("Wprowadz plik z podpisem");
            }
        }

    }
}
