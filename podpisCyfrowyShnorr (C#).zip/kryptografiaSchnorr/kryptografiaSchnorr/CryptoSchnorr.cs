﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Security.Cryptography; 

namespace kryptografiaSchnorr
{
    public class CryptoSchnorr
    {
        private int P_bity = 512;
        private int Q_bity = 160;

        /*Inicjalizacja zmiennych*/

        BigInteger P;
        BigInteger Q;
        BigInteger H;
        BigInteger A;
        BigInteger V;

        /*-------------------------------------------*/

        /*Wygenerowanie potrzebnych danych i kluczy*/
        public CryptoSchnorr()
        {
            generowaniePQH(out P, out Q, out H);
            generowanieKluczy(out A, out V);
        }

        /*-------------------------------------------*/

        /*Losowanie liczby dodatniej i pierwszej*/

        private BigInteger losowanieLiczbyDodatniej(int Bit_dlugosc)
        {
            RNGCryptoServiceProvider objRNG = new RNGCryptoServiceProvider();

            byte[] dane = new byte[(int)Math.Ceiling(Bit_dlugosc / 8.0)];
            objRNG.GetBytes(dane);
            dane[dane.Length - 1] &= (byte)0x7F;

            return new BigInteger(dane);
        }

        private BigInteger losowanieLiczbyPierwszej(int Bit_dlugosc)
        {
            BigInteger wynik = new BigInteger();

            do
            {
                wynik = losowanieLiczbyDodatniej(Bit_dlugosc);
            } while (wynik % 2 == 0 || !wynik.isProbablePrime(10));

            return wynik;
        }

        /*-------------------------------------------*/

        /*Generowanie zmiennych P, Q, A, H*/

        internal void generowaniePQH(out BigInteger P, out BigInteger Q, out BigInteger H)
        {
            Q = losowanieLiczbyPierwszej(Q_bity);
            P = ObliczPzQ(Q, P_bity, out BigInteger R);
            H = generowanieH(P, R);
        }

        private BigInteger ObliczPzQ(BigInteger Q, int Bit_ilosc, out BigInteger R)
        {
            BigInteger P = new BigInteger();

            do
            {
                R = losowanieLiczbyDodatniej(Bit_ilosc - Q_bity);
                P = (Q * R) + 1;
            } while (P % 2 == 0 || !P.isProbablePrime(10));

            return P;
        }

        private BigInteger generowanieH(BigInteger P, BigInteger R)
        {
            BigInteger baza = losowanieLiczbyDodatniej(P_bity - 2);
            BigInteger H = baza.modPow(R, P);

            while (H == 1)
            {
                baza = baza + 1;
                H = baza.modPow(R, P);
            }

            return H;
        }

        /*-------------------------------------------*/

        /*Generowanie klucza prywatnego i publicznego*/

        internal void generowanieKluczy(out BigInteger kluczPrywatny, out BigInteger kluczPubliczny)
        {
            kluczPrywatny = losowanieBigIntegerMniejszegoOd(Q);
            kluczPubliczny = generowanieKluczaPublicznego(H, A, P);
        }

        private BigInteger losowanieBigIntegerMniejszegoOd(BigInteger num)
        {
            byte[] bajty = num.getBytes();
            BigInteger RR;

            RNGCryptoServiceProvider objRNG = new RNGCryptoServiceProvider();

            do
            {
                objRNG.GetBytes(bajty);
                bajty[bajty.Length - 1] &= (byte)0x7F;
                RR = new BigInteger(bajty);
            } while (RR >= num);

            return RR;
        }

        private BigInteger generowanieKluczaPublicznego(BigInteger H, BigInteger A, BigInteger P)
        {
            return modPowDowolnyZnak(H, -A, P);
        }

        /*-------------------------------------------*/
        private byte[] laczenie_bajtow(byte[] pierwszy, byte[] drugi)
        {
            byte[] tablica = new byte[pierwszy.Length + drugi.Length];
            Buffer.BlockCopy(pierwszy, 0, tablica, 0, pierwszy.Length);
            Buffer.BlockCopy(drugi, 0, tablica, pierwszy.Length, drugi.Length);
            return tablica;
        }

        /*Łączy dwa byte array'e (konkatenacja) i używa funkcji hashującej, przerabiając je na hash*/
        private BigInteger hashBigInteger(byte[] wiadomosc, BigInteger yy)
        {
            return new BigInteger(SHA1.Create().ComputeHash(laczenie_bajtow(wiadomosc, yy.getBytes())));
        }

        /*-------------------------------------------*/

        /*Funkcja potęgi modulo dla dowolnego znaku*/
        private BigInteger modPowDowolnyZnak(BigInteger wartosc, BigInteger exp, BigInteger modul)
        {
            if (exp < 0)
            {
                var zmiennaT = wartosc.modPow(modul - 2, modul);
                return zmiennaT.modPow(-exp, modul);
            }

            return wartosc.modPow(exp, modul);
        }

        /*-------------------------------------------*/

        /******************Metody publiczne******************/

        /*Funkcja weryfikująca poprawność podpisu*/
        public bool weryfikacjaPodpisu(byte[] wiadomosc, string podpisS1, string podpisS2)
        {
            try
            {
                var S1 = new BigInteger(podpisS1, 10);
                var S2 = new BigInteger(podpisS2, 10);
                var zmiennaPrim = (modPowDowolnyZnak(H, S2, P) * modPowDowolnyZnak(V, S1, P)) % P;

                return hashBigInteger(wiadomosc, zmiennaPrim) == S1;
            }
            catch (Exception excep)
            {
                return false;
            }
        }

        /*-------------------------------------------*/

        /*Funkcja generująca podpis*/
        public Tuple<string, string> generowaniePodpisu(byte[] wiadomosc)
        {
            var R = losowanieBigIntegerMniejszegoOd(Q);

            var X = H.modPow(R, P);

            var S1 = hashBigInteger(wiadomosc, X);

            var S2 = (R + A * S1) % Q;

            return new Tuple<string, string>(S1.ToString(), S2.ToString());
        }

        /*-------------------------------------------*/
    }
}
