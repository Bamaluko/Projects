from functions import utworz_aproksymacje, utworz_punkty, blad_aproksymacji
from matplotlib import pyplot as plt


while (True):
    print("\n\n\nAproksymacja funkcji przy uzyciu metody opartej o wielomiany Hermita. ")
    print('Jaka funkcje mam aproksymować?: \n 1. y = |x| \n 2. Liniowa y = 4x + 1 \n 3. Wielomianowa y = x^3 + 2x^2 + x - 2\n'
          ' 4. Trygonometryczna y = sin(2x)\n 5. Złożona y = |cos((2x)^2 + 1) * x|')
    funkcja = int(input('Wpisz 1, 2, 3, 4 lub 5, aby wybrac funkcje do aproksymacji. Dowolny inny klawisz zakonczy dzialanie programu.\n'))
    if funkcja >= 1 and funkcja <= 5:
        print('Funkcja zostala wybrana. Okreslamy przedzial:\n')
        a: float = float(input('\nPodaj poczatek przedzialu'))
        b: float = float(input('\nPodaj koniec przedzialu'))

        # Poziom wielomianu Hermite'a.
        k: int = int(input('\nJaki poziom wielomianu: '))

        # Ponizsza funkcja wyprodukuje nam punkty dla przedzialu w bliskim odstepie od siebie (sa one)
        # potrzebne by narysowac wykres oryginalnej funkcji
        X, Y = utworz_punkty(a, b, funkcja)

        # Zaczynamy aproksymację. Do odpowiedniej funkcji wysyłamy następujące dane:
        # -poziom wielomianu Hermita
        # -krańce przedziałów.
        # -funkcję aproksymowaną
        # Poniższa tablica 'aproks' będzie zawierać wartości aproksymacji, a tablica 'wspolczynniki' wartosci
        # wspolczynników Hermita
        aproks, wspolczynniki = utworz_aproksymacje(a, b, k, funkcja)
        print("Wspolczynniki (od najwyższego stopnia, do najniższego): " + str(wspolczynniki))

        # Liczenie bledu aproksymacji
        print("Blad aproksymacji:" + str(blad_aproksymacji(Y, aproks)))

        # Wykresy funkcji:
        fig = plt.figure("Radosna aproksymacja")
        plot1 = plt.subplot(1, 1, 1)
        plot1.plot(X, Y, '-r')
        plot1.plot(X, aproks, '-b')
        plt.show()

    else:
        print("\n\nProgram zostal zakonczony.\n\n")
        break