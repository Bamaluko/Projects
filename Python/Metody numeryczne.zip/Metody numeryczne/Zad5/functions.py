import math
import numpy

N = 8

def schemat_hornera(x: float, wspolczynniki: list[float]):
    wynik: float = 0
    for wspolczynnik in wspolczynniki:
        wynik = wynik * x + wspolczynnik
    return wynik


def wartosc_funkcji(x, funkcja):
    # Funkcja modulo |x|.
    if funkcja == 1:
        return abs(x)
    # Funkcja liniowa 4*x + 1.
    elif funkcja == 2:
        return 4 * x + 1
    # Funkcja wielomianowa x^3 + 2x^2 + x - 2.
    elif funkcja == 3:
        return schemat_hornera(x, [1, 2, 1, -2])
    # Funkcja trygonometryczna sin(2x).
    elif funkcja == 4:
        return numpy.sin(x)
    # Funkcja zlozona |cos((2x)^2 + 1) * x|
    elif funkcja == 5:
        return abs(numpy.cos(2*x * 2*x + 1)*x)


# Oblicza wartość w(x)*f(x)*g(x) potrzebna do calki w mianowniku (obliczanie wspolczynnika c aproksymacji).
def wartosc_licznika(x: float, funkcja: int, k: int):
    # Zwracamy wartosc funkcji w punkcie x pomnozona z e^(-x^2).
    return math.exp(-(x**2)) * wartosc_funkcji(x, funkcja) * wielomiany_hermitta(x, k)


# Oblicza wartość w(x)*g(x)*g(x) potrzebna do calki w mianowniku (obliczanie wspolczynnika c aproksymacji).
def wartosc_mianownika(x: float, k: int):
    # Zwracamy wartosc funkcji w punkcie x pomnozona z e^(-x^2).
    return math.exp(-(x**2)) * wielomiany_hermitta(x, k) * wielomiany_hermitta(x, k)


# Funkcja ta potrzebna jest do utworzenia wykresow. Obliczamy wartosci dla odpowiednich
# x (rozciagajacych sie w ramach sprecyzowanego przedzialu co 0.01) w danej funkcji.
# Zapisujemy wyniki w listach X oraz Y i zwracamy je.
def utworz_punkty(a: float, b: float, funkcja: int):
    lista_x: list[float] = []
    lista_y: list[float] = []
    for x in numpy.arange(a, b, 0.01):
        lista_x.append(x)
        lista_y.append(wartosc_funkcji(x, funkcja))
    return lista_x, lista_y


def utworz_aproksymacje(a, b, k, funkcja):
    lista_y_apr: list[float] = []
    wspolczynniki: list[float] = oblicz_wszystkie_wspolczynniki(funkcja, k, a, b)
    for x in numpy.arange(a, b, 0.01):
        lista_y_apr.append(aproksymuj(x, wspolczynniki))
    return lista_y_apr, wspolczynniki


def metoda_simpsona_licznik(a: float, b: float, funkcja: int, k: int):
    s: float = 0  # wartosci zewnetrzne podprzedzialow (nie liczac a i b, mnozone przez 2)
    st: float = 0  # wartosci srodkowe (beda mnozeone przez 4)
    h: float = (b - a) / N  # dlugosc jednego podprzedzialu

    for i in range(1, N + 1):
        x: float = a + i * h  # obliczamy wartosc punktu podzialowego
        st += wartosc_licznika(x - h / 2, funkcja, k)  # obliczamy wartosc w punkcie srodkowym

        if i < N:
            s += wartosc_licznika(x, funkcja, k)
    return h / 6 * (wartosc_licznika(a, funkcja, k) + wartosc_licznika(b, funkcja, k) + 2 * s + 4 * st)  # wzor Simpsona


def metoda_simpsona_mianownik(a: float, b: float, k: int):
    s: float = 0  # wartosci zewnetrzne podprzedzialow (nie liczac a i b, mnozone przez 2)
    st: float = 0  # wartosci srodkowe (beda mnozeone przez 4)
    h: float = (b - a) / N  # dlugosc jednego podprzedzialu

    for i in range(1, N + 1):
        x: float = a + i * h  # obliczamy wartosc punktu podzialowego
        st += wartosc_mianownika(x - h / 2, k)  # obliczamy wartosc w punkcie srodkowym

        if i < N:
            s += wartosc_mianownika(x, k)
    return h / 6 * (wartosc_mianownika(a, k) + wartosc_mianownika(b, k) + 2 * s + 4 * st)  # wzor Simpsona


def wielomiany_hermitta(x: float, stopien: int):
    lista = [1, 2*x]
    for i in range(2, stopien+1):
        lista.append(2*x*lista[i-1] - 2*(i-1)*lista[i-2])
    return lista[stopien]


def oblicz_wszystkie_wspolczynniki(funkcja: int, k: int, a: float, b: float):
    c: [float] = []
    # Poniewaz range 0 do k da nam ostatni wielomian poziomu k - 1
    for i in range(0, k + 1):
        c.append((metoda_simpsona_licznik(a, b, funkcja, i) / metoda_simpsona_mianownik(a, b, i)))
    return c


def aproksymuj(x: float, c: list[float]):
    i: int = 0
    wynik: float = 0
    for wspolczynnik in c:
        wynik += wspolczynnik * wielomiany_hermitta(x, i)
        i += 1
    return wynik

def blad_aproksymacji(Y: list[float], A: list[float]):
    sum: float = 0
    for i in range(len(Y)):
        sum+=(Y[i]-A[i])**2
    return math.sqrt(sum)


# Opis dzialania programu:
# By dokonac aproksymacji najpierw uruchamiamy funkcje oblicz_wszystkie_wspolczynniki
# Funkcja ta zwroci nam do maina liste wspolczynnikow c, ktora sobie zachowujemy do zmiennej.
#
# Jako parametry podajemy kolejno identyfikator aproksymowanej funkcji, poziom wielomianu aproksymujacego
# (Hermitte'a) i krance przedzialow. Ta funkcja tworzy liste c na wspolczynniki i uzupelnia ja wywolywaniem
# po kolei az osiagnie poziom rowny wielomianowi aproksymujacemu (k) nastepujacych dzialan:
#
# calka na przedziale ab f(x)*w(x)*gk(x) / calka na przedziale ab w(x)*gk(x)*gk(x)
# Tak liczymy wspolczynnik ck, a potrzebujemy ich kolejno c0, c1, c2, ..., ck
#
# Calki te liczymy nastepujaco. Mamy dwie funkcje wykorzystujace calkowanie Simpsona
# na stale okreslonej ilosci przedzialow N. Jedyna roznica miedzy metodami jest taka, ze
# gdy potrzebuja wartosci w funkcji calkowanej, to jedna odwola sie do funkcji obliczajacej
# licznik f(x)*w(x)*g(x), a druga do funkcji obliczajacej mianownik w(x)*g(x)*g(x).
#
# Gdy lista jest juz gotowa to przy obliczaniu w mainie wartosci w funkcji aproksymowanej dla punktu
# wystarczy uruchomic funkcje aproksymuj. Przyjmuje ona x (punkt dla ktorego obliczamy wartosc) i
# liste wspolczynnikow. Nastepnie wykonuje po prostu dzialanie y(x) = c0*g0(x) + c1*g1(x) + ... + cn*gn(x)