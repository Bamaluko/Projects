import numpy
import sympy

def wartosc_funkcji(x: float, funkcja):
    # Zwraca wartosc funkcji dla okreslonego argumentu x
    if funkcja == "A":  # funkcja liniowa
         return 5 * x + 2
    elif funkcja == "B":  # wartosc bezwzgledna z x
        return abs(x)
    elif funkcja == "C":  # funkcja wielomianowa
        return schemat_hornera([3, 1, -1, 2], x)  # obliczenie wartosci schematem hornera
    elif funkcja == "D":  # funkcja trygonometryczna
        return 2 * numpy.cos(x) + numpy.sin(x)
    else:  # funkcja złożona
        return -2 * numpy.cos(x) + 5 * abs(x) + x**2


def wzor_funkcji(funkcja):
    # Uzywamy sympy by zapisac wzor funkcji przy pomocy zmiennej x
    x = sympy.Symbol('x')
    if funkcja == "A":  # funkcja liniowa
        return 5 * x + 2
    elif funkcja == "B":  # wartosc bezwzgledna z x
        return abs(x)
    elif funkcja == "C":  # funkcja wielomianowa
        return schemat_hornera([3, 1, -1, 2], x)  # obliczenie wartosci schematem hornera
    elif funkcja == "D":  # funkcja trygonometryczna
        return 2 * numpy.cos(x) + numpy.sin(x)
    else:  # funkcja złożona
        return -2 * numpy.cos(x) + 5 * abs(x) + x**2


def schemat_hornera(wspolczynniki, x):
    # Przyjmujemy wspolczynniki wielomianu (od tych, ktore stoja przy najwyzszej potedze),
    # a takze argument, dla ktorego obliczamy wartosc
    zwracana_wartosc = 0
    for liczba in reversed(wspolczynniki):  # pobieramy współczynniki wielomianu od końca
        zwracana_wartosc = zwracana_wartosc * x + liczba
    return zwracana_wartosc

def punkty(a: float, b: float, funkcja, X: list[float], Y: list[float]):
    # i odpowiada poczatkowi przedzialu
    i: float = a
    # bedziemy je przy jego pomocy bedziemy przygotowywac punkty co 0.01 na osi X
    # az zblizymy sie do konca przedzialu
    while i < b:
        X.append(i)
        # obliczamy wartosc funkcji dla danego X
        Y.append(wartosc_funkcji(i, funkcja))
        i += 0.01
    return X, Y


def interpolacja(wezly: list[list[float], list[float]], funkcja, a, b):
    i = a
    n: int = len(wezly[0])
    iX: list[float] = []
    iY: list[float] = []
    while i < b:
        y = 0
        for j in range(0, n):
            temp = wezly[1][j]
            for k in range(0, n):
                if j != k:
                    temp *= ((i-wezly[0][k])/(wezly[0][j]-wezly[0][k]))
            y += temp
        iX.append(i)
        iY.append(y)
        i += 0.01
    return iX, iY

def interpolacja_punktu(x, wezly: list[list[float], list[float]]):
    y: float = 0
    n: int = len(wezly[0])
    for j in range(0, n):
        temp = wezly[1][j]
        for k in range(0, n):
            if j != k:
                temp *= ((x-wezly[0][k])/(wezly[0][j]-wezly[0][k]))
        y += temp
    return y
