from functions import wartosc_funkcji, punkty, interpolacja, interpolacja_punktu
from matplotlib import pyplot as plt

while (True):
    print("\n\n\nInterpolacja funkcji przy uzyciu metody Lagrange'a dla nierownych odstepow argumentu. ")
    print('Jaka funkcje mam interpolowac?: \n A. Liniowa y = 5x + 2 \n B. y = |x| \n C. Wielomianowa y = 3x^3 + x^2 - x + 2\n'
          ' D. Trygonometryczna y = cos(x)\n E. Złożona y = -2*cos(x) + 5*|x| + x^2')
    funkcja = input('Wpisz A, B, C, D lub E, aby wybrac funkcje do interpolacji. Dowolny inny klawisz zakonczy dzialanie programu.\n').upper()
    if funkcja == "A" or funkcja == "B" or funkcja == "C" or funkcja == "D" or funkcja == "E":
        print('Funkcja zostala wybrana. Okreslamy przedzial:\n')
        a: float = float(input('\nPodaj poczatek przedzialu'))
        b: float = float(input('\nPodaj koniec przedzialu'))

        # Poniższe tablice pozwolą nam odwzorować wykres funkcji bazowej
        X: list[float] = []
        Y: list[float] = []
        # Poniższa tablica będzie zawierać węzły (X) i ich wartości w bazowej funkcji
        wezly = [[], []]

        # Ponizsza funkcja wyprodukuje nam punkty dla przedzialu w bliskim odstepie od siebie (sa one)
        # potrzebne by narysowac wykres oryginalnej funkcji
        X, Y = punkty(a, b, funkcja, X, Y)

        # Z pliku wczytamy kolejne wezly, a nastepnie obliczymy dla nich wartosci w funkcji bazowej.
        plik = open("nodes.txt", 'r')
        zawartosc = plik.readlines()
        for linia in zawartosc:
            wezly[0].append(float(linia))
            wezly[1].append(float(wartosc_funkcji(wezly[0][-1], funkcja)))
        print("Wczytane wezly oraz ich wartosci w funkcji bazowej: ")
        print(wezly)

        # Zaczynamy interpolację. Do odpowiedniej funkcji wysyłamy następujące dane:
        # -naszą tablicę węzłów i ich wartości w funkcji,
        # -identyfikator funkcji, którą interpolujemy,
        # -krańce przedziałów.
        # Końcowe dane zapisujemy w listach iX oraz iY.

        interpolowaneX: list[float]
        interpolowaneY: list[float]
        interpolowaneX, interpolowaneY = interpolacja(wezly, funkcja, a, b)

        # Wykresy funkcji:
        fig = plt.figure("Radosna interpolacja")
        plot1 = plt.subplot(1, 1, 1)
        plot1.plot(interpolowaneX, interpolowaneY, '-b')
        plot1.plot(X, Y, '-r')
        plot1.plot(wezly[0], wezly[1], '*y')
        plt.show()

        # Obliczanie interpolowanej wartości dla punktu
        punkt:float
        punkt = float(input("Podaj punkt do interpolacji: "))
        print("\nWartosc funkcji dla podanego punktu obliczona za pomoca interpolacji: " + str(interpolacja_punktu(punkt, wezly)))
        print("Wartosc funkcji dla podanego punktu obliczona ze wzoru funkcji: " + str(wartosc_funkcji(punkt, funkcja)))
        print("Blad dla " + str(len(wezly[0])) + " wezlow: " + str(abs(interpolacja_punktu(punkt, wezly) - wartosc_funkcji(punkt, funkcja))))

    else:
        print("\n\nProgram zostal zakonczony.\n\n")
        break