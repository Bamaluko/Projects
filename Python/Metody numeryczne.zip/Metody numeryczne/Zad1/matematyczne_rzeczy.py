import sympy
import numpy

def metoda_bisekcji(a, b, epsilon, wymaganych_iteracji, funkcja):

    # Funkcja szuka miejsca zerowego metodą bisekcji
    miejsce_zerowe = 0

    # Sprawdzamy, czy na koncach przedzialu mamy przeciwne znaki. Jesli nie, nie mozemy zastosowac algorytmu
    if wartosc_funkcji(a, funkcja) * wartosc_funkcji(b, funkcja) > 0:
        return False, False, False

    else:
        # liczba wymaganych iteracji pozostawiona jako zero oznacza,
        # ze uzytkownik wybral kryterium zwiazane z dokladnoscia
        if wymaganych_iteracji == 0:
            # przy kryterium z epsilonem bedziemy sprawdzac ile iteracji bylo trzeba, aby zakonczyc dzialanie algorytmu
            wykonanych_iteracji = 1
            # tworzymy symbol 'x' przy pomocy sympy...
            x = sympy.Symbol('x')
            # ...i uzywamy go do obliczenia pochodnej funkcji
            pochodna = sympy.diff(wzor_funkcji(funkcja))
            while True:
                # dzielimy przedzial na polowy
                miejsce_zerowe = (a + b) / 2
                # dla wzoru na pochodna podstawiamy w miejsce x aktualnie wyznaczona polowe
                # i obliczamy wartosc
                obliczona_pochodna = pochodna.subs(x, miejsce_zerowe)
                # Warunek konczacy dzialanie algorytmu
                #  - wartosc funkcji jest dostatecznie bliska zera
                #  - funkcja nie dazy tutaj do stalej wartosci (przeciecie osi, warunek z pochodna)
                if abs(wartosc_funkcji(miejsce_zerowe, funkcja)) <= epsilon and (abs(obliczona_pochodna) > epsilon):
                    return miejsce_zerowe, wykonanych_iteracji, abs(wartosc_funkcji(miejsce_zerowe, funkcja))
                # Dzieki iloczynowi krancow dwoch powstalych przedzialow sprawdzamy ktory z nich zawiera miejsce zerowe
                # (jesli iloczyn jest ujemny, to tam funkcja przecina os y = 0). Zmieniamy odpowiednia wartosc a lub b
                # tak, aby kolejna iteracja zostala wykonana na nowo wybranym przedziale.
                elif wartosc_funkcji(miejsce_zerowe, funkcja) * wartosc_funkcji(a, funkcja) < 0:
                    b = miejsce_zerowe
                else:
                    a = miejsce_zerowe
                wykonanych_iteracji += 1

        # liczba epsilon pozostawiona jako zero oznacza, ze uzytkownik
        # wybral kryterium zwiazane z iloscia iteracji
        else:
            # warunek konczacy (wykonanie odpowiedniej ilosci iteracji) zapisany jest w petli
            for wykonanych_iteracji in range(wymaganych_iteracji):
                # dzielimy przedzial na polowy
                miejsce_zerowe = (a + b) / 2
                # moze sie zdazyc, ze uda nam sie wczesniej osiagnac idealne miejsce zerowe
                # wowczas konczymy dzialanie algorytmu wczesniej
                if wartosc_funkcji(miejsce_zerowe, funkcja) == 0:
                    return miejsce_zerowe, wykonanych_iteracji, 0
                # Dzieki iloczynowi krancow dwoch powstalych przedzialow sprawdzamy ktory z nich zawiera miejsce zerowe
                # (jesli iloczyn jest ujemny, to tam funkcja przecina os y = 0). Zmieniamy odpowiednia wartosc a lub b
                # tak, aby kolejna iteracja zostala wykonana na nowo wybranym przedziale.
                if wartosc_funkcji(miejsce_zerowe, funkcja) * wartosc_funkcji(a, funkcja) < 0:
                    b = miejsce_zerowe
                else:
                    a = miejsce_zerowe
            # po zakonczeniu dzialania zwracamy miejsce zerowe, ilosc wykonanych iteracji i osiagnieta dokladnosc
            return miejsce_zerowe, wymaganych_iteracji, abs(wartosc_funkcji(miejsce_zerowe, funkcja))


def metoda_stycznych(a, b, epsilon, wymaganych_iteracji, funkcja):

    # Sprawdzamy, czy na koncach przedzialu mamy przeciwne znaki. Jesli nie, nie mozemy zastosowac algorytmu
    if wartosc_funkcji(a, funkcja) * wartosc_funkcji(b, funkcja) > 0:
        return False, False, False

    # tworzymy symbol 'x' przy pomocy sympy...
    x = sympy.Symbol('x')
    # ...i uzywamy go do obliczenia pochodnej funkcji
    pochodna = sympy.diff(wzor_funkcji(funkcja))
    # Jesli wartosc bezw. pochodnej dla poczatku przedialu jest mniejsza od wartosci bezw. dla konca przedzialu
    # to koniec przedzialu daje nam miejsce rozpoczecia dzialania algorytmu
    if abs(pochodna.subs(x, a)) < abs(pochodna.subs(x, b)):
        miejsce_zerowe = b
    # Jesli odwrotnie, to punktem poczatku dzialania lgorytmu bedzie poczatek przedzialu
    elif abs(pochodna.subs(x, a)) > abs(pochodna.subs(x, b)):
        miejsce_zerowe = a
    # W wyjatkowej sytuacji pochodne sa sobie rowne. Wtedy przyjmujemy srodek przedzialu
    else:
        miejsce_zerowe = (a + b) / 2

    # liczba wymaganych iteracji pozostawiona jako zero oznacza,
    # ze uzytkownik wybral kryterium zwiazane z dokladnoscia
    if wymaganych_iteracji == 0:
        # przy kryterium z epsilonem bedziemy sprawdzac ile iteracji bylo trzeba, aby zakonczyc dzialanie algorytmu
        wykonanych_iteracji = 1
        while True:
            # Sprawdzamy wartosc funkcji dla aktualnego punktu
            obliczona_wartosc_funkcji = wartosc_funkcji(miejsce_zerowe, funkcja)
            # A takze obliczamy dla niego pochodna
            obliczona_pochodna = pochodna.subs(x, miejsce_zerowe)

            # Warunek konczacy dzialanie algorytmu
            #  - wartosc funkcji jest dostatecznie bliska zera
            #  - funkcja nie dazy tutaj do stalej wartosci (przeciecie osi, warunek z pochodna)
            if abs(wartosc_funkcji(miejsce_zerowe, funkcja)) <= epsilon and (abs(obliczona_pochodna) > epsilon):
                return miejsce_zerowe, wykonanych_iteracji, abs(wartosc_funkcji(miejsce_zerowe, funkcja))
            # Gdy to jeszcze nie jest koniec dzialania algorytmu, wowczas musimy nadac nowa wartosc argumentowi na bazie stycznej
            #  xn+1 = xn - f(xn)/f'(xn)
            miejsce_zerowe = miejsce_zerowe - float(obliczona_wartosc_funkcji / obliczona_pochodna)
            # Zaznaczamy, ze rozpoczynamy kolejna iteracje
            wykonanych_iteracji += 1

    # liczba epsilon pozostawiona jako zero oznacza, ze uzytkownik
    # wybral kryterium zwiazane z iloscia iteracji
    else:
        for wykonanych_iteracji in range(wymaganych_iteracji):

            # moze sie zdazyc, ze uda nam sie wczesniej osiagnac idealne miejsce zerowe
            # wowczas konczymy dzialanie algorytmu wczesniej
            if wartosc_funkcji(miejsce_zerowe, funkcja) == 0:
                return miejsce_zerowe, wykonanych_iteracji, 0

            # Sprawdzamy wartosc funkcji dla aktualnego punktu
            obliczona_wartosc_fukcji = wartosc_funkcji(miejsce_zerowe, funkcja)
            # A takze obliczamy dla niego pochodna
            obliczona_pochodna = pochodna.subs(x, miejsce_zerowe)
            # Gdy to jeszcze nie jest koniec dzialania algorytmu, wowczas musimy nadac nowa wartosc argumentowi na bazie stycznej
            #  xn+1 = xn - f(xn)/f'(xn)
            miejsce_zerowe = miejsce_zerowe - float(obliczona_wartosc_fukcji / obliczona_pochodna)
        return miejsce_zerowe, wymaganych_iteracji, abs(wartosc_funkcji(miejsce_zerowe, funkcja))

def wartosc_funkcji(x, funkcja):
    # Zwraca wartosc funkcji dla okreslonego argumentu x
    if funkcja == "A":  # funkcja wielomianowa
        return schemat_hornera([5, 2, -1, 5], x)  # obliczenie wartosci schematem hornera
    elif funkcja == "B":  # funkcja trygonometryczna
        return 5 * numpy.cos(x) - 3 * numpy.sin(x)
    elif funkcja == "C":  # funkcja wykładnicza
        return 2 ** x - 5 ** x
    else:  # funkcja złożona
        return -3 * numpy.sin(x) + 2 * x ** 2 - 1


def wzor_funkcji(funkcja):
    # Uzywamy sympy by zapisac wzor funkcji przy pomocy zmiennej x
    x = sympy.Symbol('x')
    if funkcja == "A":  # funkcja wielomianowa (uzywamy schematu hornera do obliczen)
        return schemat_hornera([5, 2, -1, 5], x)
    elif funkcja == "B":  # funkcja trygonometryczna
        return 5 * sympy.cos(x) - 3 * sympy.sin(x)
    elif funkcja == "C":  # funkcja wykładnicza
        return 2 ** x - 5 ** x
    else:  # funkcja złożona
        return -3 * sympy.sin(x) + 2 * x ** 2 - 1

def schemat_hornera(wspolczynniki, x):
    # Przyjmujemy wspolczynniki wielomianu (od tych, ktore stoja przy najwyzszej potedze),
    # a takze argument, dla ktorego obliczamy wartosc
    zwracana_wartosc = 0
    for liczba in reversed(wspolczynniki):    # pobieramy współczynniki wielomianu od końca
        zwracana_wartosc = zwracana_wartosc * x + liczba
    return zwracana_wartosc