from matematyczne_rzeczy import metoda_bisekcji, metoda_stycznych

#Wiadomosc wyswietlana przy uruchomieniu programu
def powitanie():
    print("Ten program ma za zadanie odnalezc miejsce zerowe dla rownan nieliniowych.")
    print("Zaimplementowane metody: ")
    print("   - Metoda bisekcji")
    print("   - Metoda stycznych (Newtona)")
    print("Wariant: |f(xi)|<ε")
    input("\nWcisnij ENTER, aby kontynuowac")
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")

def menu():
    lewy_przedzial:int = 0
    prawy_przedzial:int = 0
    kryterium:int
    epsilon:float = 0
    wymaganych_iteracji:int = 0
    ilosc_iteracji:int = 0

    # Wybieramy oczekiwana funkcje
    print("Wybierz funkcje, ktora ma zostac wykorzystana:")
    print("A - wielomianowa")
    print("B - trygonometryczna")
    print("C - wykladnicza")
    print("D - zlozona")
    funkcja = input("Wpisz A, B, C lub D, aby dokonac wyboru. Dowolny inny klawisz zakonczy dzialanie programu.\n").upper()
    if funkcja == "A" or funkcja == "B" or funkcja == "C" or funkcja == "D":
        liczba_podana = False
        #Wybieramy lewy przedzial
        while liczba_podana is False:
            try:
                lewy_przedzial = int(input("Podaj lewy przedzial(liczba calkowita): "))
                liczba_podana = True
            except ValueError:
                print("Wartosc nieprawidlowa, wprowadz liczbe calkowita.")
        else:
            liczba_podana = False
        # Wybieramy prawy przedzial
        while liczba_podana is False:
            try:
                prawy_przedzial = int(input("Podaj prawy przedzial(liczba calkowita): "))
                if prawy_przedzial <= lewy_przedzial:
                    print("Prawy przedizal musi miec wieksza wartosc, niz lewy.")
                else :
                    liczba_podana = True
            except ValueError:
                print("Wartosc nieprawidlowa, wprowadz liczbe calkowita.")
        else:
            liczba_podana = False
        # Wybieramy kryterium zakonczenia (dokladnosc lub iteracje)
        while liczba_podana is False:
            try:
                kryterium = int(input("Wybierz kryterium zakonczenia dzialania algorytmu.\n"
                                            "'1' - osiagniecie wymaganej dokladnosci\n'2' - osiagniecie wymaganej ilosci iteracji\n"))
                if kryterium != 1 and kryterium != 2:
                    print("Prosze wybrac wartosc '1' lub '2'.")
                else :
                    liczba_podana = True
            except ValueError:
                print("Wartosc nieprawidlowa, wprowadz liczbe calkowita '1' lub '2'.")
        # Podajemy informacje potrzebne dla danego kryterium
        liczba_podana = False
        if kryterium == 1:
            while liczba_podana is False:
                try:
                    epsilon = abs(float(input("Podaj oczekiwana dokladnosc rozna od 0 (zalecana liczba zmiennoprzecinkowa): ")))
                    if epsilon == 0:
                        print("Wprowadz prawidlowa wartosc.")
                    else:
                        liczba_podana = True
                except ValueError:
                    print("Wprowadz prawidlowa wartosc.")
        else:
            while liczba_podana is False:
                try:
                    wymaganych_iteracji = int(input("Podaj dodatnia calkowita liczbe czekiwanych iteracji: "))
                    if wymaganych_iteracji < 1:
                        print("Wartosc nieprawidlowa, wprowadz liczbe calkowita, dodatnia.")
                    else:
                        liczba_podana = True
                except ValueError:
                    print("Wartosc nieprawidlowa, wprowadz liczbe calkowita, dodatnia.")

        # DLA METODY BISEKCJI
        miejsce_zerowe, wykonanych_iteracji, dokladnosc = metoda_bisekcji(lewy_przedzial, prawy_przedzial, epsilon, wymaganych_iteracji, funkcja)
        print("\n\n\n----------METODA BISEKCJI----------")
        if not miejsce_zerowe and not wykonanych_iteracji and not dokladnosc:
            print("Nie mozna bylo wykonac algorytmu dla podanych parametrow.")
        else:
            print("Obliczone miejsce zerowe: ", miejsce_zerowe)
            print("Liczba wykonanych iteracji: ", wykonanych_iteracji)
            print("Osiagnieta dzieki danej metodzie dokladnosc: ", dokladnosc)

        # DLA METODY STYCZNYCH
        print("\n\n\n----------METODA STYCZNYCH----------")
        miejsce_zerowe, wykonanych_iteracji, dokladnosc = metoda_stycznych(lewy_przedzial, prawy_przedzial, epsilon, wymaganych_iteracji, funkcja)
        if not miejsce_zerowe and not wykonanych_iteracji and not dokladnosc:
            print("Nie mozna bylo wykonac algorytmu dla podanych parametrow.")
        else:
            print("Obliczone miejsce zerowe: ", miejsce_zerowe)
            print("Liczba wykonanych iteracji: ", wykonanych_iteracji)
            print("Osiagnieta dzieki danej metodzie dokladnosc: ", dokladnosc)
        print("\n\n\n")
        return True

    else :
        return False


#main
nie_wylaczaj = True
powitanie()
while nie_wylaczaj:
    nie_wylaczaj = menu()
