from functions import gauss_legendre_m, wzor_funkcji, simpson

while (True):
    print("\n\n\nCałkowanie numeryczne metodą kwadratury Newtona-Cotesa oraz kwadratury Gaussa-Legendre'a. ")
    print('Wybierz na jakiej funkcje mamy dzialac: \n A. Liniowa y = 5x + 2 \n B. y = |x| \n C. Wielomianowa y = 3x^3 + x^2 - x + 2\n'
          ' D. Trygonometryczna y = cos(x))\n E. Złożona y = -2*cos(x) + 5*|x| + x^2')
    funkcja = input('Wpisz A, B, C, D lub E, aby wybrac funkcje do interpolacji. Dowolny inny klawisz zakonczy dzialanie programu.\n').upper()
    if funkcja == "A" or funkcja == "B" or funkcja == "C" or funkcja == "D" or funkcja == "E":
        print('Funkcja zostala wybrana. Okreslamy przedzial:\n')
        a: float = float(input('\nPodaj poczatek przedzialu: '))
        b: float = float(input('\nPodaj koniec przedzialu: '))
        e: float = float(input('\n\nPodaj wartosc epsilon: '))

        # Wypisywanie informacji na ekran

        print("Funkcja: " + str(wzor_funkcji(funkcja)))
        print("Przedzial:" + str(a) + " - " + str(b))
        print("Epsilon: " + str(e))

        # Metoda Simpsona
        iteracje=1
        stara_calka=0
        calka=simpson(a,b,funkcja,iteracje)
        while(abs(stara_calka-calka)>e):
            iteracje+=1
            stara_calka = calka
            calka = simpson(a,b,funkcja,iteracje)

        print("\n\n Metoda Simpsona: " + str(calka) + "\n\n Liczba iteracji: " + str(iteracje))

        # Kwadratura Gaussa-Legendre'a

        print("\n\n Kwadratura Gaussa-Legendre'a dla: \n")

        for j in range(2,6):
            print("\n - " + str(j) + " wezlow: " + str(gauss_legendre_m(a,b,funkcja, j)))


    else:
        print("\n\nProgram zostal zakonczony.\n\n")
        break