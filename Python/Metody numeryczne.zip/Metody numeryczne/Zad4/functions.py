import numpy
import sympy

wartosci = [[-0.577350269189626, 0.577350269189626, 0, 0, 0],
            [-0.774596669241483, 0.0, 0.774596669241483, 0, 0],
            [-0.861136311594053, -0.339981043584856, 0.339981043584856, 0.861136311594053, 0],
            [-0.906179845938664, -0.538469310105683, 0.0, 0.538469310105683, 0.906179845938664]]


def schemat_hornera(wspolczynniki, x):
    # Przyjmujemy wspolczynniki wielomianu (od tych, ktore stoja przy najwyzszej potedze),
    # a takze argument, dla ktorego obliczamy wartosc
    zwracana_wartosc = 0
    for liczba in reversed(wspolczynniki):  # pobieramy współczynniki wielomianu od końca
        zwracana_wartosc = zwracana_wartosc * x + liczba
    return zwracana_wartosc


def wartosc_funkcji(x: float, funkcja):
    # Zwraca wartosc funkcji dla okreslonego argumentu x
    if funkcja == "A":  # funkcja liniowa
        return 5 * x + 2
    elif funkcja == "B":  # wartosc bezwzgledna z x
        return abs(x)
    elif funkcja == "C":  # funkcja wielomianowa
        return schemat_hornera([3, 1, -1, 2], x)  # obliczenie wartosci schematem hornera
    elif funkcja == "D":  # funkcja trygonometryczna
        return numpy.cos(x)
    else:  # funkcja złożona
        return -2 * numpy.cos(x) + 5 * abs(x) + x ** 2


def wzor_funkcji(funkcja):
    # Uzywamy sympy by zapisac wzor funkcji przy pomocy zmiennej x
    x = sympy.Symbol('x')
    if funkcja == "A":  # funkcja liniowa
        return 5 * x + 2
    elif funkcja == "B":  # wartosc bezwzgledna z x
        return abs(x)
    elif funkcja == "C":  # funkcja wielomianowa
        return schemat_hornera([3, 1, -1, 2], x)  # obliczenie wartosci schematem hornera
    elif funkcja == "D":  # funkcja trygonometryczna
        return sympy.cos(x)
    else:  # funkcja złożona
        return -2 * sympy.cos(x) + 5 * abs(x) + x ** 2


def simpson(a, b, opcja, N):
    s = 0  # wartosci zewnetrzne podprzedzialow (nie liczac a i b, mnozone przez 2)
    st = 0  # wartosci srodkowe (beda mnozeone przez 4)
    h = (b - a) / N  # dlugosc jednego podprzedzialu

    for i in range(1, N + 1):
        x = a + i * h  # obliczamy wartosc punktu podzialowego
        st += wartosc_funkcji(x - h / 2, opcja)  # obliczamy wartosc w punkcie srodkowym

        if (i < N):
            s += wartosc_funkcji(x, opcja)

    return h / 6 * (wartosc_funkcji(a, opcja) + wartosc_funkcji(b, opcja) + 2 * s + 4 * st)  # wzor Simpsona


def gauss_legendre_p(n, b, xk):
    if not n and not b:
        return 1
    elif n == 1 and not b:
        return xk
    elif not b:
        wynik = ((2 * (n - 1) + 1) / n) * xk * gauss_legendre_p(n - 1, 0, xk) - (
                ((n - 1) / n) * gauss_legendre_p(n - 2, 0, xk))
        if abs(wynik) < 0.001: wynik = 0
        return wynik

    else:
        wynik = (((n * gauss_legendre_p(n - 1, 0, xk)) / (xk ** 2 - 1)) -
                 (n * xk * gauss_legendre_p(n, 0, xk) / (xk ** 2 - 1)))
        if abs(wynik) < 0.001:
            wynik = 0
        return wynik


def gauss_legendre_m(a, b, opcja, N):
    wynik = 0

    for k in range(N):
        x_temp = ((a + b) / 2) + (((b - a) / 2) * wartosci[N - 2][k])
        Ak = ((-2) / ((N + 1) * gauss_legendre_p(N + 1, 0, wartosci[N - 2][k]) * gauss_legendre_p(N, 1, wartosci[N - 2][k])))

        wynik += -Ak * wartosc_funkcji(x_temp, opcja)
    return wynik * ((b - a) / 2)
