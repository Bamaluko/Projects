from matrixes import M, V


def isDiagonallyDominant():
    diagonally_dominant: bool = True
    for i in range(0, len(M)):
        suma: int = 0
        for j in range(0, len(M[i])):
            suma += abs(M[i][j])
        suma -= abs(M[i][i])
        if suma > abs(M[i][i]):
            diagonally_dominant = False
            break
    return diagonally_dominant


def algorithmEpsilon(epsilon: float, solutions: list[float]):
    iterations: int = 1
    while True:
        solutions_copy = solutions.copy()
        for row_number in range(len(M)):
            solutions[row_number] = countElement(row_number, solutions_copy)
        if isBelowError(solutions, solutions_copy, epsilon):
            print("Wykonanych iteracji: ", iterations)
            break
        iterations += 1
    return solutions


def isBelowError(solutions: list[float], solutions_copy: list[float], epsilon: float):
    for solution, solution_copy in zip(solutions, solutions_copy):
        if abs(solution - solution_copy) > epsilon:
            return False
    return True


def algorithmIterations(limit: int, solutions: list[float]):
    for iteration in range(limit):
        solutions_copy = solutions.copy()
        for row_number in range(len(M)):
            solutions[row_number] = countElement(row_number, solutions_copy)
    return solutions


def countElement(row_number: int, solutions: list[float]):
    suma: int = 0
    for element1, element2 in zip(M[row_number], solutions):
        suma -= element1 * element2
    suma += V[row_number]
    suma += M[row_number][row_number] * solutions[row_number]
    return suma / M[row_number][row_number]


if __name__ == '__main__':

    """Sprawdzamy, czy ilosc wektorow wchodzacych w sklad macierzy jest odpowiednia, aby mozna bylo wykonac
    iloczyn macierzy z wektorem."""
    if len(M) != len(V):
        raise Exception("Ilosc zmiennych w macierzy i dlugosc wektora wyrazow wolnych nie sa ze soba zgodne.")

    """Sprawdzamy, czy macierz jest kwadratowa."""
    for column in M:
        if len(column) != len(M):
            raise Exception("UWAGA!!! Macierz musi byc kwadratowa.")

    """W koncu sprawdzamy, czy macierz jest diagonalnie dominujaca."""
    # if not isDiagonallyDominant():
    #     raise Exception("Macierz nie spelnia warunkow zbieznosci.")

    """Tworzymy odpowiednio dlugi wektor pierwszych szacowan rozwiazania."""
    solutions: list[float] = []
    for element in M[0]:
        solutions.append(0)

    choice: int = 0
    while choice not in range(1, 3):
        choice: int = int(input("Wybierz kryterium zakonczenia algorytmu:\n1.Dokladnosc\n2.Ilosc iteracji\n"))
    if choice == 1:
        epsilon: float = float(input("Podaj dokladnosc\n"))
        solutions = algorithmEpsilon(epsilon, solutions)
    else:
        limit = int(input("Podaj ilosc iteracji\n"))
        solutions = algorithmIterations(limit, solutions)

    print(solutions)
