"""Przykład 0 (poprawnie wylicza)"""
# M = [[8, 1, 2, 3],
#     [1, 6, 1, -1],
#     [2, 1, 18, 2],
#     [3, -1, 2, 40]]
#
# V = [28, 12, 66, 167]

"""Przykład A (nie spelnia warunkow zbieznosci)"""
#
M = [[3, 3, 1],
      [2, 5, 7],
      [1, 2, 1]]

V = [12, 33, 8]

"""Przykład B (nie spelnia warunkow zbieznosci)"""
# M = [[3, 3, 1],
#      [2, 5, 7],
#      [-4, -10, -17]]
#
# V = [1, 20, -40]

"""Przykład C (nie spelnia warunkow zbieznosci)"""
# M = [[3, 3, 1],
#      [2, 5, 7],
#      [-4, -10, -17]]
#
# V = [1, 20, -20]

"""Przykład D (poprawnie wylicza)"""
# M = [[0.5, -0.0625, 0.1875, 0.0625],
#      [-0.0625, 0.5, 0, 0],
#      [0.1875, 0, 0.375, 0.125],
#      [0.0625, 0, 0.125, 0.25]]
#
# V = [1.5, -1.625, 1, 0.4375]

"""Przykład E (nie spelnia warunkow zbieznosci)"""
# M = [[3, 2, 1, -1],
#      [5, -1, 1, 2],
#      [1, -1, 1, 2],
#      [7, 8, 1, -7]]
#
# V = [0, -4, 4, 6]

"""Przykład F (nie spelnia warunkow zbieznosci)"""
# M = [[3, -1, 1, -1],
#      [3, -1, 1, 1],
#      [1, 2, -1, 2],
#      [-1, 1, -2, -3]]
#
# V = [-13, 1, 21, -5]

"""Przykład G (nie spelnia warunkow zbieznosci)"""
# M = [[0, 0, 1],
#      [1, 0, 0],
#      [0, 1, 0]]
#
# V = [3, 7, 5]

"""Przykład H (nie spelnia warunkow zbieznosci)"""
# M = [[10, -5, 1],
#      [4, -7, 2],
#      [5, 1, 4]]
#
# V = [3, -4, 19]

"""Przykład I (nie spelnia warunkow zbieznosci)"""
# M = [[6, -4, 2],
#      [-5, 5, 2],
#      [0.9, 0.9, 3.6]]
#
# V = [4, 11, 13.5]


"""Przykład J (dobrze wylicza)"""
# M = [[1, 0.2, 0.3],
#      [0.1, 1, -0.3],
#      [-0.1, -0.2, 1]]
#
# V = [1.5, 0.8, 0.7]

