let playerXStart = 10;
let playerYStart = 110;

let player2XStart = 10;
let player2YStart = 510;

let playerX = 10;                  
let playerY = 110;        
let playerW = 80;                  
let playerH = 80;     

let player2X = 10;                  
let player2Y = 510;        
let player2W = 80;                  
let player2H = 80; 

let speedX = 0;
let speedY = 0;

let speed2X = 0;
let speed2Y = 0;

let metaX = 1300;
let metaY = 350;
let metaW = 100;
let metaH = 100;

let player;
let player2;
let obstacleShape;
let meta;

let container;

let isWon = false;
let isLost = false;
let counter = 0;

let winText = "Nothing";

function setup() {
  createCanvas(1400,800);           
  fill(0,255,0);               
  textSize(13);   
  player = loadImage("assets/player.svg");
  player2 = loadImage("assets/player2.svg");
  obstacleShape = loadImage("assets/brick.svg");
  meta = loadImage("assets/meta.svg");
  
  container = new ObstacleContainer();

  //container.list.push(new Obstacle(obstacleShape, 0, 500, 100, 100, 0, 0));
  //container.list.push(new Obstacle(obstacleShape, 100, 500, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 100, 400, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 100, 300, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 100, 200, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 100, 100, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 200, 100, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 300, 100, 100, 100, 0, 0));
  
  container.list.push(new Obstacle(obstacleShape, 500, 0, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 500, 100, 100, 100, 0, 0));
  //container.list.push(new Obstacle(obstacleShape, 500, 200, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 500, 300, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 400, 300, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 300, 300, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 300, 400, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 300, 500, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 0, 600, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 0, 700, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 100, 700, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 200, 700, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 300, 700, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 400, 700, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 500, 700, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 500, 600, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 500, 500, 100, 100, 0, 0));
  
  container.list.push(new Obstacle(obstacleShape, 700, 700, 100, 100, 0, -700));
  container.list.push(new Obstacle(obstacleShape, 1000, 0, 100, 100, 0, 350));
  container.list.push(new Obstacle(obstacleShape, 1000, 700, 100, 100, 0, -350));
  container.list.push(new Obstacle(obstacleShape, 1100, 0, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 1100, 100, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 1100, 200, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 1100, 500, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 1100, 600, 100, 100, 0, 0));
  container.list.push(new Obstacle(obstacleShape, 1100, 700, 100, 100, 0, 0));
}


function draw() {
  if(isWon)
  {
    background(0, 255, 100);
    fill(20, 0, 100);
    text(winText, 350, 400);
    playerX = playerXStart;
    playerY = playerYStart;
    player2X = player2XStart;
    player2Y = player2YStart;
    counter++;
    if(counter == 150)
    {
      counter = 0;
      isWon = false;
    }
  }
  
  else
  {
    background(255, 140, 140);
    image(player, playerX, playerY, playerW, playerH);
    image(player2, player2X, player2Y, player2W, player2H);
    playerX += speedX;
    playerY += speedY;
    player2X += speed2X;
    player2Y += speed2Y;
    container.DrawAll();
    container.MoveAll();
    image(meta, metaX, metaY, metaW, metaH);
  
    if (playerX + playerW > metaX &&     
    playerX < metaX + metaW &&      
    playerY + playerH > metaY &&       
    playerY < metaY + metaH)
    {
      winText = "Player1 WINS";
      isWon = true;
    }
    
    if (player2X + player2W > metaX &&     
    player2X < metaX + metaW &&      
    player2Y + player2H > metaY &&       
    player2Y < metaY + metaH)
    {
      winText = "Player2 WINS";
      isWon = true;
    }
    
    else if(container.CheckAll(playerX, playerY, playerW, playerH) || playerX < 0 || playerY < 0 || playerX > width - playerW || playerY > height - playerH)
    {
      playerX -= speedX;
      playerY -= speedY;
      playerX = playerXStart;
      playerY = playerYStart;
      counter = 0;
    }
    
    else if(container.CheckAll(player2X, player2Y, player2W, player2H) || player2X < 0 || player2Y < 0 || player2X > width - player2W || player2Y > height - player2H)
    {
      player2X -= speed2X;
      player2Y -= speed2Y;
      player2X = player2XStart;
      player2Y = player2YStart;
      counter = 0;
    }
    
    else if (playerX + playerW > player2X &&     
    playerX < player2X + player2W &&      
    playerY + playerH > player2Y &&       
    playerY < player2Y + player2H) {       
      playerX -= speedX;
      playerY -= speedY;
      playerX = playerXStart;
      playerY = playerYStart;
      player2X -= speed2X;
      player2Y -= speed2Y;
      player2X = player2XStart;
      player2Y = player2YStart;
      counter = 0;
  }
    textSize(28);
    fill(0, 255, 0);
    text("Use 'wasd' and arrows to move. Avoid obstacles and screen boundaries!", 10, 780);
    textSize(128);
  }
}
