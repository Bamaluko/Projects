class Obstacle
{
  //public PShape shape;
  //public int x, y, w, h, xbis, ybis;
  //private boolean movingToOther = true;
  //private int movementCounter = 0;
  
  constructor(shape1, x1, y1, w1, h1, xbis1, ybis1)
  {
    this.shape = shape1;
    this.x = x1;
    this.y = y1;
    this.w = w1;
    this.h = h1;
    this.xbis = xbis1;
    this.ybis = ybis1;
    this.movementCounter = 0;
    this.movingToOther = true;
  }
  
  //constructor(shape1, x1, y1, w1, h1, xbis1, ybis1)
  //{
  //  this.shape = shape1;
  //  this.x = x1;
  //  this.y = y1;
  //  this.w = w1;
  //  this.h = h1;
  //  this.xbis = xbis1;
  //  this.ybis = ybis1;
  //}
  
  draw()
  {
     image(this.shape, this.x, this.y);
  }
  
  move()
  {
    if(this.xbis != 0 || this.ybis != 0)
    {
       if(this.movingToOther)
       {
         this.x = this.x + this.xbis/100;
         this.y = this.y + this.ybis/100;
         this.movementCounter++;
         if(this.movementCounter == 100)
         {
           this.movingToOther = false;
         }
       }
       else
       {
         this.x = this.x - this.xbis/100;
         this.y = this.y - this.ybis/100;
         this.movementCounter--;
         if(this.movementCounter == 0)
         {
           this.movingToOther = true;
         }
       }
    }
  }
  
  CheckCollsion(px, py, pw, ph)
  {
    
  if (this.x + this.w > px &&     
    this.x < px + pw &&      
    this.y + this.h > py &&       
    this.y < py + ph) {       
      return true;
  }
  return false;
  }
}
