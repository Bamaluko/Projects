function keyPressed()
{
  if (key =='w') {
    speedY = -3;
  }
  
    if (key =='s') {
    speedY = 3;
  }
  
  if (key =='a') {
    speedX = -3;
  }
  
  if (key =='d') {
    speedX = 3;
  }
  
  if (keyCode == UP_ARROW) {
    speed2Y = -3;
  }
  
  if (keyCode == DOWN_ARROW) {
    speed2Y = 3;
  }
  
  if (keyCode == LEFT_ARROW) {
    speed2X = -3;
  }
  
  if (keyCode == RIGHT_ARROW) {
    speed2X = 3;
  }
  
}

function keyReleased()
{
  if (key =='w') {
    speedY = 0;
  }
  
    if (key =='s') {
    speedY = 0;
  }
  
  if (key =='a') {
    speedX = 0;
  }
  
  if (key =='d') {
    speedX = 0;
  }
  
  if (keyCode == UP_ARROW) {
    speed2Y = 0;
  }
  
  if (keyCode == DOWN_ARROW) {
    speed2Y = 0;
  }
  
  if (keyCode == LEFT_ARROW) {
    speed2X = 0;
  }
  
  if (keyCode == RIGHT_ARROW) {
    speed2X = 0;
  }
}
