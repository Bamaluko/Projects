class ObstacleContainer
{
   
   constructor()
   {
      this.list = [];
   }
   
   DrawAll()
   {
     for(let i = 0; i < this.list.length; i++) 
     {
        this.list[i].draw();
     }
   }
   
   MoveAll()
   {
     for(let i = 0; i < this.list.length; i++) 
     {
        this.list[i].move();
     }
   }
   
   CheckAll(px, py, pw, ph)
   {
     for(let i = 0; i < this.list.length; i++) 
     {
       if(this.list[i].CheckCollsion(px, py, pw, ph))
       {
         return true;
       }
     }
     
     return false;
   }
}
